import java.util.Scanner;

public class RemoveDuplicates_2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter size of array: ");
        int n = sc.nextInt();

        int[] arr = new int[n];
        System.out.println("Enter array elements:");
        for(int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        int[] uniqueArr = removeDuplicates(arr);

        System.out.println("Array after removing duplicates:");
        for (int i = 0; i < uniqueArr.length; i++) {
            System.out.print(uniqueArr[i] + " ");
        }
        sc.close();
    }

    static int[] removeDuplicates(int[] arr) {
        int n = arr.length;
        int[] temp = new int[n];
        int j = 0;

        for (int i = 0; i < n; i++) {
            boolean isDuplicate = false;
            // Check if arr[i] is already in temp
            for (int k = 0; k < j; k++) {
                if (arr[i] == temp[k]) {
                    isDuplicate = true;
                    break;
                }
            }
            if (!isDuplicate) {
                temp[j++] = arr[i];
            }
        }

        // Copy unique elements into an array of proper size
        int[] uniqueArr = new int[j];
        for (int i = 0; i < j; i++) {
            uniqueArr[i] = temp[i];
        }

        return uniqueArr;
    }
}
