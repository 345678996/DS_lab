import java.util.Scanner;

public class ArrayOperations_1{
    static int[] arr;
    static int size = 0; // current number of elements

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean exit = false;

        while (!exit) {
            System.out.println("\n——MENU——-");
            System.out.println("1. CREATE");
            System.out.println("2. DISPLAY");
            System.out.println("3. INSERT");
            System.out.println("4. DELETE");
            System.out.println("5. LINEAR SEARCH");
            System.out.println("6. EXIT");
            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    createArray(sc);
                    break;
                case 2:
                    displayArray();
                    break;
                case 3:
                    insertElement(sc);
                    break;
                case 4:
                    deleteElement(sc);
                    break;
                case 5:
                    linearSearch(sc);
                    break;
                case 6:
                    exit = true;
                    System.out.println("Exiting program...");
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }

        sc.close();
    }

    // Create array and take input from user
    static void createArray(Scanner sc) {
        System.out.print("Enter the size of the array: ");
        int n = sc.nextInt();
        arr = new int[n];
        size = 0;
        System.out.println("Enter " + n + " elements:");
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }
        size = n;
        System.out.println("Array created successfully.");
    }

    // Display the elements of array
    static void displayArray() {
        if (arr == null || size == 0) {
            System.out.println("Array is empty. Please create array first.");
            return;
        }
        System.out.print("Array elements: ");
        for (int i = 0; i < size; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }

    // Insert an element at a given position
    static void insertElement(Scanner sc) {
        if (arr == null) {
            System.out.println("Array not created yet. Please create array first.");
            return;
        }
        if (size == arr.length) {
            System.out.println("Array is full. Cannot insert element.");
            return;
        }

        System.out.print("Enter the element to insert: ");
        int element = sc.nextInt();
        System.out.print("Enter the position to insert (1 to " + (size + 1) + "): ");
        int pos = sc.nextInt();

        if (pos < 1 || pos > size + 1) {
            System.out.println("Invalid position!");
            return;
        }

        // shift elements right
        for (int i = size - 1; i >= pos - 1; i--) {
            arr[i + 1] = arr[i];
        }

        arr[pos - 1] = element;
        size++;
        System.out.println("Element inserted successfully.");
    }

    // Delete element from a given position
    static void deleteElement(Scanner sc) {
        if (arr == null || size == 0) {
            System.out.println("Array is empty. Nothing to delete.");
            return;
        }
        System.out.print("Enter the position of element to delete (1 to " + size + "): ");
        int pos = sc.nextInt();

        if (pos < 1 || pos > size) {
            System.out.println("Invalid position!");
            return;
        }

        // shift elements left
        for (int i = pos - 1; i < size - 1; i++) {
            arr[i] = arr[i + 1];
        }
        size--;
        System.out.println("Element deleted successfully.");
    }

    // Linear search for an element
    static void linearSearch(Scanner sc) {
        if (arr == null || size == 0) {
            System.out.println("Array is empty.");
            return;
        }
        System.out.print("Enter element to search: ");
        int key = sc.nextInt();

        for (int i = 0; i < size; i++) {
            if (arr[i] == key) {
                System.out.println("Element found at position: " + (i + 1));
                return;
            }
        }
        System.out.println("Element not found in the array.");
    }
}
