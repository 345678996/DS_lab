import java.util.Scanner;

public class ArrayMatrixOperations_4 {

    // Method to reverse an array
    public static void reverseArray(int[] arr) {
        int start = 0, end = arr.length - 1;
        while (start < end) {
            int temp = arr[start];
            arr[start] = arr[end];
            arr[end] = temp;
            start++;
            end--;
        }
    }

    // Method to multiply two matrices
    public static int[][] multiplyMatrices(int[][] mat1, int[][] mat2) {
        int r1 = mat1.length;
        int c1 = mat1[0].length;
        int r2 = mat2.length;
        int c2 = mat2[0].length;

        if (c1 != r2) {
            throw new IllegalArgumentException("Matrix multiplication not possible: columns of mat1 != rows of mat2");
        }

        int[][] result = new int[r1][c2];

        for (int i = 0; i < r1; i++) {
            for (int j = 0; j < c2; j++) {
                for (int k = 0; k < c1; k++) {
                    result[i][j] += mat1[i][k] * mat2[k][j];
                }
            }
        }
        return result;
    }

    // Method to transpose a matrix
    public static int[][] transposeMatrix(int[][] matrix) {
        int rows = matrix.length;
        int cols = matrix[0].length;
        int[][] transpose = new int[cols][rows];

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                transpose[j][i] = matrix[i][j];
            }
        }

        return transpose;
    }

    // Helper method to print an array
    public static void printArray(int[] arr) {
        for (int val : arr) {
            System.out.print(val + " ");
        }
        System.out.println();
    }

    // Helper method to print a matrix
    public static void printMatrix(int[][] matrix) {
        for (int[] row : matrix) {
            for (int val : row) {
                System.out.print(val + " ");
            }
            System.out.println();
        }
    }

    // Main method to demonstrate usage
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Reverse array demo
        System.out.print("Enter size of array to reverse: ");
        int n = sc.nextInt();
        int[] arr = new int[n];
        System.out.println("Enter array elements:");
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }
        reverseArray(arr);
        System.out.print("Reversed array: ");
        printArray(arr);

        // Matrix multiplication demo
        System.out.println("\nMatrix Multiplication:");
        System.out.print("Enter rows and columns for matrix 1: ");
        int r1 = sc.nextInt();
        int c1 = sc.nextInt();
        int[][] mat1 = new int[r1][c1];
        System.out.println("Enter matrix 1 elements:");
        for (int i = 0; i < r1; i++) {
            for (int j = 0; j < c1; j++) {
                mat1[i][j] = sc.nextInt();
            }
        }

        System.out.print("Enter rows and columns for matrix 2: ");
        int r2 = sc.nextInt();
        int c2 = sc.nextInt();
        int[][] mat2 = new int[r2][c2];
        System.out.println("Enter matrix 2 elements:");
        for (int i = 0; i < r2; i++) {
            for (int j = 0; j < c2; j++) {
                mat2[i][j] = sc.nextInt();
            }
        }

        try {
            int[][] product = multiplyMatrices(mat1, mat2);
            System.out.println("Product of matrices:");
            printMatrix(product);
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }

        // Transpose matrix demo
        System.out.println("\nTranspose of matrix 1:");
        int[][] transpose = transposeMatrix(mat1);
        printMatrix(transpose);

        sc.close();
    }
}
