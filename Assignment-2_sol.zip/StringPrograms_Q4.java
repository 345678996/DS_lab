import java.util.Scanner;

public class StringPrograms_Q4 {

    // (a) Concatenate two strings manually
    public static String concatenate(String s1, String s2) {
        char[] result = new char[s1.length() + s2.length()];
        int i = 0;
        for (; i < s1.length(); i++) {
            result[i] = s1.charAt(i);
        }
        for (int j = 0; j < s2.length(); j++) {
            result[i + j] = s2.charAt(j);
        }
        return new String(result);
    }

    // (b) Reverse a string manually
    public static String reverse(String s) {
        char[] result = new char[s.length()];
        int j = 0;
        for (int i = s.length() - 1; i >= 0; i--) {
            result[j++] = s.charAt(i);
        }
        return new String(result);
    }

    // (c) Remove vowels manually
    public static String removeVowels(String s) {
        String vowels = "AEIOUaeiou";
        char[] temp = new char[s.length()];
        int j = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            boolean isVowel = false;
            for (int k = 0; k < vowels.length(); k++) {
                if (c == vowels.charAt(k)) {
                    isVowel = true;
                    break;
                }
            }
            if (!isVowel) {
                temp[j++] = c;
            }
        }
        return new String(temp, 0, j);
    }

    // (d) Sort strings alphabetically (Bubble Sort)
    public static void sortStrings(String[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (compareStrings(arr[j], arr[j + 1]) > 0) {
                    // Swap
                    String temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }
    // (e) Convert uppercase to lowercase manually
    private static int compareStrings(String s1, String s2) {
    int len = Math.min(s1.length(), s2.length());
    for (int i = 0; i < len; i++) {
        char c1 = Character.toUpperCase(s1.charAt(i));
        char c2 = Character.toUpperCase(s2.charAt(i));
        if (c1 != c2) {
            return c1 - c2;
        }
    }
    return s1.length() - s2.length();
}

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // (a) Concatenate
        System.out.print("Enter first string: ");
        String s1 = sc.nextLine();
        System.out.print("Enter second string: ");
        String s2 = sc.nextLine();
        System.out.println("Concatenated String: " + concatenate(s1, s2));

        // (b) Reverse
        System.out.print("\nEnter a string to reverse: ");
        String s3 = sc.nextLine();
        System.out.println("Reversed String: " + reverse(s3));

        // (c) Remove vowels
        System.out.print("\nEnter a string to remove vowels: ");
        String s4 = sc.nextLine();
        System.out.println("Without Vowels: " + removeVowels(s4));

        // (d) Sort strings
        System.out.print("\nEnter number of strings to sort: ");
        int n = sc.nextInt();
        sc.nextLine(); // consume newline
        String[] arr = new String[n];
        System.out.println("Enter " + n + " strings:");
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextLine();
        }
        sortStrings(arr);
        System.out.println("Sorted Strings: ");
        for (String str : arr) {
            System.out.println(str);
        }

        // (e) Uppercase → Lowercase
        System.out.print("\nEnter a character to convert to lowercase: ");
        char c = sc.next().charAt(0);
        System.out.println("Lowercase Character: " + Character.toLowerCase(c));


        sc.close();
    }
}
