public class MissingNumber_Q3 {

    // (a) Linear time approach
    public static int findMissingLinear(int[] arr, int n) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] != i + 1) {
                return i + 1; // Missing number found
            }
        }
        return n; // If nothing missing till n-1, then missing is n
    }

    // (b) Binary search approach
    public static int findMissingBinary(int[] arr, int n) {
        int low = 0, high = arr.length - 1;

        while (low <= high) {
            int mid = low + (high - low) / 2;

            if (arr[mid] == mid + 1) {
                // If value matches index+1, missing number is on right side
                low = mid + 1;
            } else {
                // Otherwise, missing is on left side
                high = mid - 1;
            }
        }
        return low + 1; // Missing number
    }

    public static void main(String[] args) {
        // Example array: numbers from 1 to 8, but 4 is missing
        int[] arr = {1, 2, 3, 5, 6, 7, 8};
        int n = 8; // Should be range 1..n

        System.out.println("Missing number (Linear Search): " + findMissingLinear(arr, n));
        System.out.println("Missing number (Binary Search): " + findMissingBinary(arr, n));
    }
}
